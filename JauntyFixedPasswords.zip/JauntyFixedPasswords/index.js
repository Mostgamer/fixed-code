const { Client } = require("discord.js-selfbot-v13");
const client = new Client();

// Configuration
const MESSAGE_INTERVAL = 5 * 60 * 1000; // 5 minutes in milliseconds
const DEBUG_INTERVAL = 1 * 60 * 1000; // 1 minute in milliseconds

client.on("ready", async () => {
  console.log(`${client.user.username} is ready!`);

  // Replace 'CHANNEL_ID_HERE' with your actual channel ID
  const channel = await client.channels.fetch("1353854888794132522");

  // Function to calculate and log time remaining
  function logTimeRemaining(nextSendTime) {
    const currentTime = Date.now();
    const timeLeft = nextSendTime - currentTime;
    const minutes = Math.ceil(timeLeft / 60000);
    console.log(`Next message in ${minutes} minute(s)`);
  }

  // Initial send
  channel.send("<:1DG_GiftCard:1315839218269945857>");
  let nextSendTime = Date.now() + MESSAGE_INTERVAL;
  logTimeRemaining(nextSendTime);

  // Set up message interval (5 minutes)
  const messageInterval = setInterval(() => {
    channel.send("<:1DG_GiftCard:1315839218269945857>");
    nextSendTime = Date.now() + MESSAGE_INTERVAL;
    logTimeRemaining(nextSendTime);
  }, MESSAGE_INTERVAL);

  // Debug updates every 1 minute
  const debugInterval = setInterval(() => {
    const timeLeft = nextSendTime - Date.now();
    const minutes = Math.ceil(timeLeft / 60000);
    console.debug(`Time remaining: ${minutes} minute(s)`);
  }, DEBUG_INTERVAL);
});

// Get token from Replit secrets
client.login(process.env.DISCORD_TOKEN);
